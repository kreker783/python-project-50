### Hexlet tests and linter status:
[![Actions Status](https://github.com/kreker783/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/kreker783/python-project-50/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/40bc21d5e0f21dbf7a2a/maintainability)](https://codeclimate.com/github/kreker783/python-project-50/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/40bc21d5e0f21dbf7a2a/test_coverage)](https://codeclimate.com/github/kreker783/python-project-50/test_coverage)


How gendiff json work: https://asciinema.org/a/to6YzoJjGbi0ZDZJcQUCsrfZi

How gendiff yaml work: https://asciinema.org/a/BXgXrPnTpVj0Iq8DaZ3zuxHNn

"""
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

# Cache for 1 week
git config --global credential.helper "cache --timeout=604800"







#Tocken for pypi
pypi-AgEIcHlwaS5vcmcCJDE4NDc3MjFkLTdjNGEtNDE3MC1iZDBkLWEyOWNmYzIzMDMwMwACKlszLCI3NDZlZjc2Yi00ODg4LTRmOGQtYmZlMS01M2YxMGExODFmZmQiXQAABiBVtcZIz22PSDaTBsyrvFDGI92sRDk21jKtFuDchuZA9Q
