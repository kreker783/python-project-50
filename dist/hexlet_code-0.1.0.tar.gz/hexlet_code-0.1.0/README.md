### Hexlet tests and linter status:
[![Actions Status](https://github.com/kreker783/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/kreker783/python-project-50/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/40bc21d5e0f21dbf7a2a/maintainability)](https://codeclimate.com/github/kreker783/python-project-50/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/40bc21d5e0f21dbf7a2a/test_coverage)](https://codeclimate.com/github/kreker783/python-project-50/test_coverage)


How gendiff work: https://asciinema.org/a/to6YzoJjGbi0ZDZJcQUCsrfZi
