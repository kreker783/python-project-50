### Hexlet tests and linter status:
[![Actions Status](https://github.com/kreker783/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/kreker783/python-project-50/actions)


How gendiff work: https://asciinema.org/a/to6YzoJjGbi0ZDZJcQUCsrfZi
